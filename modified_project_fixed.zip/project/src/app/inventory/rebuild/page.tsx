"use client"
import React, { useEffect, useState } from 'react'

interface Discrepancy {
  lotId: string
  productId: string
  expectedAvailable: number
  recordedAvailable: number
  qtyDelta: number
}

export default function InventoryRebuildPage() {
  const [loading, setLoading] = useState(true)
  const [discrepancies, setDiscrepancies] = useState<Discrepancy[]>([])
  const [applying, setApplying] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchReport() {
      setLoading(true)
      const res = await fetch('/api/inventory/rebuild/report')
      const json = await res.json()
      if (json.success) {
        setDiscrepancies(json.discrepancies || [])
      } else {
        setError(json.error || 'failed')
      }
      setLoading(false)
    }
    fetchReport()
  }, [])

  const applyFixes = async () => {
    if (!confirm('Apply inventory corrections?')) return
    setApplying(true)
    const res = await fetch('/api/inventory/rebuild/apply', { method: 'POST' })
    const json = await res.json()
    if (json.success) {
      setDiscrepancies([])
    } else {
      setError(json.error || 'failed')
    }
    setApplying(false)
  }

  return (
    <div className="p-4">
      <h1 className="text-xl font-semibold mb-4">Inventory Rebuild</h1>
      {error && <div className="text-red-600 mb-2">Error: {error}</div>}
      {loading ? (
        <div>Loading...</div>
      ) : (
        <>
          <table className="min-w-full text-sm border">
            <thead>
              <tr className="bg-gray-200">
                <th className="p-2 border">Lot</th>
                <th className="p-2 border">Product</th>
                <th className="p-2 border">Expected Available</th>
                <th className="p-2 border">Recorded Available</th>
                <th className="p-2 border">Delta</th>
              </tr>
            </thead>
            <tbody>
              {discrepancies.map((d) => (
                <tr key={d.lotId} className="border-b">
                  <td className="p-2 border">{d.lotId}</td>
                  <td className="p-2 border">{d.productId}</td>
                  <td className="p-2 border text-right">{d.expectedAvailable}</td>
                  <td className="p-2 border text-right">{d.recordedAvailable}</td>
                  <td className="p-2 border text-right">{d.qtyDelta}</td>
                </tr>
              ))}
              {discrepancies.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-2 text-center">No discrepancies</td>
                </tr>
              )}
            </tbody>
          </table>
          <div className="mt-4">
            <button onClick={applyFixes} disabled={applying || discrepancies.length === 0} className="px-4 py-2 bg-green-600 text-white rounded">
              {applying ? 'Applying...' : 'Apply Fixes'}
            </button>
          </div>
        </>
      )}
      <p className="mt-2 text-sm text-gray-500">If posting lock is engaged, rebuild cannot be applied.</p>
    </div>
  )
}