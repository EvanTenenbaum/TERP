import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// Generate a report of inventory discrepancies between expected and recorded available quantities.
export async function GET(req: Request) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING','READ_ONLY']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:inventory-rebuild-report`, 30, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  try {
    const lots = await prisma.inventoryLot.findMany({
      select: {
        id: true,
        quantityOnHand: true,
        quantityAllocated: true,
        quantityAvailable: true,
        batch: { select: { productId: true } },
      },
    })
    const discrepancies: any[] = []
    for (const lot of lots) {
      const expected = lot.quantityOnHand - lot.quantityAllocated
      if (expected !== lot.quantityAvailable) {
        discrepancies.push({
          lotId: lot.id,
          productId: lot.batch?.productId,
          expectedAvailable: expected,
          recordedAvailable: lot.quantityAvailable,
          qtyDelta: expected - lot.quantityAvailable,
        })
      }
    }
    return NextResponse.json({ success:true, discrepancies })
  } catch (error) {
    return NextResponse.json({ success:false, error:'failed' }, { status:500 })
  }
}