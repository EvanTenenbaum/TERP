import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import * as Sentry from '@sentry/nextjs'
import { requireRole, getCurrentUserId } from '@/lib/auth'
import { ensurePostingUnlocked } from '@/lib/system'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// Apply inventory corrections based on expected vs recorded quantities.
export async function POST(req: Request) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  try { await ensurePostingUnlocked(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'posting_locked' }, { status:423 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:inventory-rebuild-apply`, 30, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  try {
    const userId = getCurrentUserId()
    let fixedCount = 0
    await prisma.$transaction(async (tx) => {
      const lots = await tx.inventoryLot.findMany({ select: { id: true, quantityOnHand: true, quantityAllocated: true, quantityAvailable: true } })
      for (const lot of lots) {
        const expected = lot.quantityOnHand - lot.quantityAllocated
        if (expected !== lot.quantityAvailable) {
          const delta = expected - lot.quantityAvailable
          await tx.inventoryLot.update({ where: { id: lot.id }, data: { quantityAvailable: expected } })
          await tx.adjustmentLedger.create({ data: { lotId: lot.id, qtyDelta: delta, reason: 'REBUILD_CORRECTION', createdBy: userId } })
          fixedCount++
        }
      }
    })
    return NextResponse.json({ success:true, fixed: fixedCount })
  } catch (error) {
    Sentry.captureException(error)
    return NextResponse.json({ success:false, error:'failed' }, { status:500 })
  }
}