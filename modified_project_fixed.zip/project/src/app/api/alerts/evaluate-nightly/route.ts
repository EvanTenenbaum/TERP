import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import * as Sentry from '@sentry/nextjs'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET() {
  if (process.env.ENABLE_QA_CRONS !== 'true') {
    return NextResponse.json({ ok: false, error: 'disabled' }, { status: 404 })
  }
  try {
    const rules = await prisma.rule.findMany({ where: { active: true }, orderBy: { priority: 'desc' } })
    const conflicts: string[] = []
    // Track which entities are already affected by a rule to detect overlaps
    const seenTargets = new Set<string>()
    const today = new Date()
    for (const rule of rules) {
      if (rule.field === 'ARDays') {
        const ars = await prisma.accountsReceivable.findMany({ include: { customer: true } })
        for (const ar of ars) {
          const days = Math.floor((today.getTime() - new Date(ar.dueDate).getTime()) / 86400000)
          const targetVal = parseInt(rule.value, 10)
          const match = evalCondition(days, rule.operator, targetVal)
          const key = `AR:${ar.id}`
          if (match) {
            if (seenTargets.has(key)) conflicts.push(rule.id)
            seenTargets.add(key)
            if (rule.action === 'CreateTask') {
              await prisma.reminder.create({ data: { customerId: ar.customerId, dueDate: new Date(), note: `AR overdue ${days} days for ${ar.invoiceNumber}` } })
            }
          }
        }
      } else if (rule.field === 'InventoryAge') {
        const lots = await prisma.inventoryLot.findMany({ select: { id: true, lastMovementDate: true } })
        for (const lot of lots) {
          const days = Math.floor((today.getTime() - new Date(lot.lastMovementDate).getTime()) / 86400000)
          const targetVal = parseInt(rule.value, 10)
          const match = evalCondition(days, rule.operator, targetVal)
          const key = `LOT:${lot.id}`
          if (match) {
            if (seenTargets.has(key)) conflicts.push(rule.id)
            seenTargets.add(key)
            // Example action: nothing by default; extend as needed
          }
        }
      } else if (rule.field === 'QtyAvailable') {
        const lots = await prisma.inventoryLot.findMany({ select: { id: true, quantityAvailable: true } })
        for (const lot of lots) {
          const qty = lot.quantityAvailable
          const targetVal = parseInt(rule.value, 10)
          const match = evalCondition(qty, rule.operator, targetVal)
          const key = `LOT:${lot.id}`
          if (match) {
            if (seenTargets.has(key)) conflicts.push(rule.id)
            seenTargets.add(key)
            // Example action: nothing by default
          }
        }
      } else if (rule.field === 'SalesVolume') {
        // For SalesVolume we might look at order aggregates. Minimal implementation left as a placeholder.
        // Implementation can be extended to compute volume and trigger actions.
        continue
      }
    }
    if (conflicts.length) {
      // Deduplicate conflict IDs
      const unique = Array.from(new Set(conflicts))
      await prisma.ruleConflict.create({ data: { ruleIds: unique.join(',') } })
    }
    return NextResponse.json({ ok: true })
  } catch (e) {
    Sentry.captureException(e)
    return NextResponse.json({ ok: false, error: 'alerts_failed' }, { status: 500 })
  }
}

function evalCondition(actual: number, op: string, target: number): boolean {
  switch (op) {
    case '>': return actual > target
    case '>=': return actual >= target
    case '<': return actual < target
    case '<=': return actual <= target
    case '==': return actual === target
    case '!=': return actual !== target
    default: return false
  }
}
