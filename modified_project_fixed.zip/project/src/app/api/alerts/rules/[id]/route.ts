import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:alerts-rules-patch`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  const body = await req.json().catch(() => ({})) as any
  const { field, operator, value, action, priority, active } = body || {}
  // Validate combos if provided
  const updateData: any = {}
  if (field) updateData.field = field
  if (operator) updateData.operator = operator
  if (value !== undefined) updateData.value = String(value)
  if (action) updateData.action = action
  if (priority !== undefined) updateData.priority = Number(priority)
  if (active !== undefined) updateData.active = !!active
  try {
    const updated = await prisma.rule.update({ where: { id: params.id }, data: updateData })
    return NextResponse.json({ success:true, rule: updated })
  } catch (error) {
    return NextResponse.json({ success:false, error:'failed' }, { status:500 })
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:alerts-rules-delete`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  try {
    await prisma.rule.delete({ where: { id: params.id } })
    return NextResponse.json({ success:true })
  } catch (error) {
    return NextResponse.json({ success:false, error:'failed' }, { status:500 })
  }
}