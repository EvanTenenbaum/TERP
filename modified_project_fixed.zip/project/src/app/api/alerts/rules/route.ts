import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// Handle listing and creation of alert rules
export async function GET(req: Request) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:alerts-rules-get`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  const rules = await prisma.rule.findMany({ orderBy: { priority: 'desc' } })
  return NextResponse.json({ success:true, data: rules })
}

export async function POST(req: Request) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:alerts-rules-post`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  const body = await req.json().catch(() => ({})) as any
  const { field, operator, value, action, priority, active } = body || {}
  // Validate field/operator combos
  const validFields: Record<string, string[]> = {
    InventoryAge: ['>','>=','<','<=','==','!='],
    QtyAvailable: ['>','>=','<','<=','==','!='],
    ARDays: ['>','>=','<','<=','==','!='],
    SalesVolume: ['>','>=','<','<=','==','!='],
  }
  if (!field || !operator || !value || !action) {
    return NextResponse.json({ success:false, error:'invalid_input' }, { status:400 })
  }
  if (!validFields[field] || !validFields[field].includes(operator)) {
    return NextResponse.json({ success:false, error:'invalid_operator' }, { status:400 })
  }
  const rule = await prisma.rule.create({ data: { field, operator, value: String(value), action: String(action), priority: Number(priority) || 0, active: active !== false } })
  return NextResponse.json({ success:true, rule })
}