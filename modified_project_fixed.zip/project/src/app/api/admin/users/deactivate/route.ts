import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import * as Sentry from '@sentry/nextjs'
import { requireRole, getCurrentUserId } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// Deactivate or reactivate a user account. Only SUPER_ADMIN may perform this action.
export async function POST(req: Request) {
  try { requireRole(['SUPER_ADMIN']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:admin-users-deactivate`, 30, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  try {
    const body = await req.json().catch(() => ({})) as any
    const { userId, deactivated, reason } = body || {}
    if (!userId || typeof deactivated !== 'boolean') {
      return NextResponse.json({ success:false, error:'invalid_input' }, { status:400 })
    }
    const updated = await prisma.user.update({ where: { id: userId }, data: { deactivated } })
    // Record audit note
    const noteContent = `User ${deactivated ? 'deactivated' : 'reactivated'}${reason ? ': ' + reason : ''}`
    try {
      await prisma.crmNote.create({ data: { customerId: null, vendorId: null, noteDate: new Date(), noteType: 'USER_DEACTIVATE', content: noteContent, createdBy: getCurrentUserId() } })
    } catch (err) {
      Sentry.captureException(err)
    }
    return NextResponse.json({ success:true, user: updated })
  } catch (error) {
    Sentry.captureException(error)
    return NextResponse.json({ success:false, error:'failed' }, { status:500 })
  }
}