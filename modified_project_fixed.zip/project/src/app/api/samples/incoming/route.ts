import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { ensurePostingUnlocked } from '@/lib/system'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'
import { getActiveBatchCostDb } from '@/lib/cogs'

// Handle incoming sample transactions (samples received from vendors)
// Body fields: productId (string, required), vendorId (string, required), qty (number, required), batchId (string, optional), notes (string, optional)
// For incoming samples we only record the transaction and optionally snapshot cost; inventory is not modified.
// RBAC: SUPER_ADMIN, SALES, ACCOUNTING
// Rate: 60 requests per minute
// Posting lock enforced
export async function POST(req: NextRequest) {
  // Enforce role-based access control
  try {
    requireRole(['SUPER_ADMIN', 'SALES', 'ACCOUNTING'])
  } catch {
    return new NextResponse('forbidden', { status: 403 })
  }
  // Ensure posting operations are unlocked
  try {
    await ensurePostingUnlocked(['SUPER_ADMIN', 'SALES', 'ACCOUNTING'])
  } catch {
    return new NextResponse('posting_locked', { status: 423 })
  }
  // Rate limiting
  const rl = rateLimit(`${rateKeyFromRequest(req)}:sample-incoming`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ error: 'rate_limited' }, { status: 429 })

  // Parse body
  const body = await req.json().catch(() => null)
  if (!body) return NextResponse.json({ error: 'bad_json' }, { status: 400 })
  const productId = body.productId ? String(body.productId) : ''
  const vendorId = body.vendorId ? String(body.vendorId) : ''
  const batchId: string | undefined = body.batchId ? String(body.batchId) : undefined
  const qtyNum = Number(body.qty)
  const notes: string | undefined = body.notes ? String(body.notes).slice(0, 512) : undefined
  if (!productId || !vendorId || !Number.isFinite(qtyNum) || qtyNum <= 0) {
    return NextResponse.json({ error: 'invalid_input' }, { status: 400 })
  }

  // Create a sample ledger entry; no inventory movement
  return await prisma.$transaction(async (tx) => {
    const now = new Date()
    let unitCost = 0
    if (batchId) {
      // If batch is provided, snapshot its cost; ignore errors silently
      try {
        const cost = await getActiveBatchCostDb(tx as any, batchId, now)
        unitCost = cost?.unitCost ?? 0
      } catch {}
    }
    await tx.sampleTransaction.create({
      data: {
        productId,
        batchId: batchId || null,
        customerId: null,
        vendorId,
        transactionType: 'VENDOR_IN',
        quantity: qtyNum,
        unitCostSnapshot: unitCost,
        transactionDate: now,
        notes,
      },
    })
    return NextResponse.json({ ok: true })
  })
}