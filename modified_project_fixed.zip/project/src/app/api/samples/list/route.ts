import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// List sample transactions with optional filtering by customerId, vendorId and date range
// Query params: customerId, vendorId, from, to
// RBAC: SUPER_ADMIN, ACCOUNTING, SALES, READ_ONLY
// Rate: 60 requests per minute
export async function GET(req: NextRequest) {
  try {
    requireRole(['SUPER_ADMIN', 'ACCOUNTING', 'SALES', 'READ_ONLY'])
  } catch {
    return new NextResponse('forbidden', { status: 403 })
  }
  const rl = rateLimit(`${rateKeyFromRequest(req)}:sample-list`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ error: 'rate_limited' }, { status: 429 })
  const { searchParams } = new URL(req.url)
  const customerId = searchParams.get('customerId') || undefined
  const vendorId = searchParams.get('vendorId') || undefined
  const fromParam = searchParams.get('from') || undefined
  const toParam = searchParams.get('to') || undefined
  let from: Date | undefined
  let to: Date | undefined
  if (fromParam) {
    const d = new Date(fromParam)
    if (!isNaN(d.getTime())) from = d
  }
  if (toParam) {
    const d = new Date(toParam)
    if (!isNaN(d.getTime())) to = d
  }
  const where: any = {}
  if (customerId) where.customerId = customerId
  if (vendorId) where.vendorId = vendorId
  if (from || to) {
    where.transactionDate = {}
    if (from) (where.transactionDate as any).gte = from
    if (to) (where.transactionDate as any).lte = to
  }
  const transactions = await prisma.sampleTransaction.findMany({
    where,
    orderBy: { transactionDate: 'desc' },
    include: {
      product: true,
      customer: true,
      vendor: true,
      batch: true,
    },
  })
  return NextResponse.json({ success: true, transactions })
}