import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { ensurePostingUnlocked } from '@/lib/system'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'
import { getActiveBatchCostDb } from '@/lib/cogs'

// Handle returned samples. These are samples that were previously sent out and are being returned either by a customer or vendor.
// Body fields: productId (string, required), qty (number, required), customerId (string, optional), vendorId (string, optional), batchId (string, optional), notes (string, optional)
// If customerId is provided, records a CLIENT_RETURN sample; if vendorId is provided, records a VENDOR_RETURN sample.
// Sample returns do not modify inventory; they simply log the transaction.
// RBAC: SUPER_ADMIN, SALES, ACCOUNTING
// Rate: 60 requests per minute
// Posting lock enforced
export async function POST(req: NextRequest) {
  try {
    requireRole(['SUPER_ADMIN', 'SALES', 'ACCOUNTING'])
  } catch {
    return new NextResponse('forbidden', { status: 403 })
  }
  try {
    await ensurePostingUnlocked(['SUPER_ADMIN', 'SALES', 'ACCOUNTING'])
  } catch {
    return new NextResponse('posting_locked', { status: 423 })
  }
  const rl = rateLimit(`${rateKeyFromRequest(req)}:sample-return`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ error: 'rate_limited' }, { status: 429 })
  const body = await req.json().catch(() => null)
  if (!body) return NextResponse.json({ error: 'bad_json' }, { status: 400 })
  const productId = body.productId ? String(body.productId) : ''
  const batchId: string | undefined = body.batchId ? String(body.batchId) : undefined
  const qtyNum = Number(body.qty)
  const customerId: string | undefined = body.customerId ? String(body.customerId) : undefined
  const vendorId: string | undefined = body.vendorId ? String(body.vendorId) : undefined
  const notes: string | undefined = body.notes ? String(body.notes).slice(0, 512) : undefined
  if (!productId || !Number.isFinite(qtyNum) || qtyNum <= 0) {
    return NextResponse.json({ error: 'invalid_input' }, { status: 400 })
  }
  // Determine transaction type
  let transactionType: 'CLIENT_RETURN' | 'VENDOR_RETURN'
  if (customerId) {
    transactionType = 'CLIENT_RETURN'
  } else if (vendorId) {
    transactionType = 'VENDOR_RETURN'
  } else {
    return NextResponse.json({ error: 'missing_target' }, { status: 400 })
  }
  return await prisma.$transaction(async (tx) => {
    const now = new Date()
    let unitCost = 0
    if (batchId) {
      try {
        const cost = await getActiveBatchCostDb(tx as any, batchId, now)
        unitCost = cost?.unitCost ?? 0
      } catch {}
    }
    await tx.sampleTransaction.create({
      data: {
        productId,
        batchId: batchId || null,
        customerId: customerId || null,
        vendorId: vendorId || null,
        transactionType,
        quantity: qtyNum,
        unitCostSnapshot: unitCost,
        transactionDate: now,
        notes,
      },
    })
    return NextResponse.json({ ok: true })
  })
}