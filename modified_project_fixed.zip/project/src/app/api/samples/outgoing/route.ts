import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { ensurePostingUnlocked } from '@/lib/system'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'
import { getActiveBatchCostDb } from '@/lib/cogs'

// Handle outgoing sample transactions (samples given to customers)
// Body fields: productId (string, required), qty (number, required), customerId (string, optional), batchId (string, optional), notes (string, optional)
// RBAC: SUPER_ADMIN, SALES, ACCOUNTING
// Rate: 60 requests per minute
// Posting lock enforced
export async function POST(req: NextRequest) {
  // Enforce role-based access control
  try {
    requireRole(['SUPER_ADMIN', 'SALES', 'ACCOUNTING'])
  } catch {
    return new NextResponse('forbidden', { status: 403 })
  }
  // Ensure posting operations are unlocked
  try {
    await ensurePostingUnlocked(['SUPER_ADMIN', 'SALES', 'ACCOUNTING'])
  } catch {
    return new NextResponse('posting_locked', { status: 423 })
  }
  // Rate limit this endpoint
  const rl = rateLimit(`${rateKeyFromRequest(req)}:sample-outgoing`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ error: 'rate_limited' }, { status: 429 })

  // Parse and validate JSON body
  const body = await req.json().catch(() => null)
  if (!body) return NextResponse.json({ error: 'bad_json' }, { status: 400 })

  const productId = body.productId ? String(body.productId) : ''
  const batchId: string | undefined = body.batchId ? String(body.batchId) : undefined
  const customerId: string | undefined = body.customerId ? String(body.customerId) : undefined
  const qtyNum = Number(body.qty)
  const notes: string | undefined = body.notes ? String(body.notes).slice(0, 512) : undefined

  if (!productId || !Number.isFinite(qtyNum) || qtyNum <= 0) {
    return NextResponse.json({ error: 'invalid_input' }, { status: 400 })
  }

  // Perform transactional operations
  return await prisma.$transaction(async (tx) => {
    // Locate an inventory lot. Prefer batchId if provided, otherwise FIFO by product
    let lot: any = null
    if (batchId) {
      // When targeting a specific batch, still apply FIFO ordering to ensure deterministic allocation
      lot = await tx.inventoryLot.findFirst({
        where: { batchId },
        orderBy: [
          { lastMovementDate: 'asc' },
          { createdAt: 'asc' },
        ],
      })
    } else {
      lot = await tx.inventoryLot.findFirst({
        where: { batch: { productId } },
        orderBy: [
          { lastMovementDate: 'asc' },
          { createdAt: 'asc' },
        ],
      })
    }
    if (!lot) {
      return NextResponse.json({ error: 'lot_not_found' }, { status: 404 })
    }
    // Compute effective available quantity (subtract reserved quantity if present)
    const effAvail = lot.quantityAvailable - (lot.reservedQty ?? 0)
    if (effAvail < qtyNum) {
      return NextResponse.json({ error: 'insufficient_available' }, { status: 409 })
    }
    const now = new Date()
    // Determine cost snapshot for the batch
    const cost = await getActiveBatchCostDb(tx as any, lot.batchId, now)
    // Update inventory quantities: decrement on-hand and available
    const newOnHand = lot.quantityOnHand - qtyNum
    const newAllocated = lot.quantityAllocated
    const newAvailable = Math.max(0, newOnHand - newAllocated)
    await tx.inventoryLot.update({
      where: { id: lot.id },
      data: {
        quantityOnHand: newOnHand,
        quantityAvailable: newAvailable,
        lastMovementDate: now,
      },
    })
    // Record the sample transaction
    await tx.sampleTransaction.create({
      data: {
        productId,
        batchId: lot.batchId,
        customerId: customerId || null,
        vendorId: null,
        transactionType: 'CLIENT_OUT',
        quantity: qtyNum,
        unitCostSnapshot: cost?.unitCost ?? 0,
        transactionDate: now,
        notes,
      },
    })
    return NextResponse.json({ ok: true })
  })
}