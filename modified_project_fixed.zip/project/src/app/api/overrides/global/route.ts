import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import * as Sentry from '@sentry/nextjs'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'
import { ensurePostingUnlocked } from '@/lib/system'
import { requireRole, getCurrentUserId } from '@/lib/auth'
import { getEffectiveUnitPrice } from '@/lib/pricing'

export async function POST(req: Request) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success: false, error: 'forbidden' }, { status: 403 }) }
  try { await ensurePostingUnlocked(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success: false, error: 'posting_locked' }, { status: 423 }) }
  // Rate limit: 60/min per IP
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:override-global`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  try {
    const body = await req.json()
    const { productId, categoryRefId, unitPrice, reason } = body || {}
    // require either a productId or categoryRefId; unitPrice must be positive
    if ((!productId && !categoryRefId) || typeof unitPrice !== 'number' || unitPrice <= 0) {
      return NextResponse.json({ success: false, error: 'invalid_input' }, { status: 400 })
    }
    if (!reason || typeof reason !== 'string' || reason.length > 256) {
      return NextResponse.json({ success: false, error: 'invalid_reason' }, { status: 400 })
    }
    const now = new Date()

    let book = await prisma.priceBook.findFirst({ where: { type: 'GLOBAL', name: 'ADMIN_GLOBAL_OVERRIDE' } })
    if (!book) {
      book = await prisma.priceBook.create({ data: { name: 'ADMIN_GLOBAL_OVERRIDE', type: 'GLOBAL', effectiveDate: now, isActive: true } })
    } else if (!book.isActive) {
      await prisma.priceBook.update({ where: { id: book.id }, data: { isActive: true } })
    }

    let oldPrice: number = 0
    if (productId) {
      // Only compute oldPrice when a specific product override is provided
      oldPrice = await getEffectiveUnitPrice(prisma as any, productId, {})
    }
    const data: any = { priceBookId: book.id, unitPrice, effectiveDate: now }
    if (productId) data.productId = productId
    if (categoryRefId) data.categoryRefId = categoryRefId
    const entry = await prisma.priceBookEntry.create({ data })

    await prisma.overrideAudit.create({ data: { userId: getCurrentUserId(), oldPrice, newPrice: unitPrice, reason: reason || 'GLOBAL_PRICE_OVERRIDE', overrideType: 'GLOBAL' } })

    return NextResponse.json({ success: true, entry })
  } catch (error) {
    console.error('global override error', error)
    Sentry.captureException(error)
    return NextResponse.json({ success: false, error: 'failed' }, { status: 500 })
  }
}
