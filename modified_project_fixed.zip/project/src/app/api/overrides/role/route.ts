import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import * as Sentry from '@sentry/nextjs'
import { requireRole, getCurrentUserId } from '@/lib/auth'
import { ensurePostingUnlocked } from '@/lib/system'
import { getEffectiveUnitPrice } from '@/lib/pricing'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

export async function POST(req: Request) {
  // RBAC: Only SUPER_ADMIN and ACCOUNTING can override role pricing
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  try { await ensurePostingUnlocked(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'posting_locked' }, { status:423 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:override-role`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  try {
    const body = await req.json().catch(() => ({})) as any
    const { productId, categoryRefId, targetId, unitPrice, reason } = body || {}
    if ((!productId && !categoryRefId) || !targetId || typeof unitPrice !== 'number' || unitPrice <= 0) {
      return NextResponse.json({ success:false, error:'invalid_input' }, { status:400 })
    }
    if (!reason || typeof reason !== 'string' || reason.length > 256) {
      return NextResponse.json({ success:false, error:'invalid_reason' }, { status:400 })
    }
    const now = new Date()
    // Find or create a role price book
    let book = await prisma.priceBook.findFirst({ where: { type:'ROLE', roleId: targetId } })
    if (!book) {
      book = await prisma.priceBook.create({ data: { name: `ROLE_${targetId}`, type:'ROLE', roleId: targetId, effectiveDate: now, isActive: true } })
    } else if (!book.isActive) {
      await prisma.priceBook.update({ where: { id: book.id }, data: { isActive: true } })
    }
    let oldPrice = 0
    if (productId) {
      oldPrice = await getEffectiveUnitPrice(prisma as any, productId, { roleId: targetId })
    }
    const data: any = { priceBookId: book.id, unitPrice, effectiveDate: now }
    if (productId) data.productId = productId
    if (categoryRefId) data.categoryRefId = categoryRefId
    const entry = await prisma.priceBookEntry.create({ data })
    await prisma.overrideAudit.create({ data: { userId: getCurrentUserId(), oldPrice, newPrice: unitPrice, reason, overrideType: 'ROLE' } })
    return NextResponse.json({ success:true, entry })
  } catch (error) {
    console.error('role override error', error)
    Sentry.captureException(error)
    return NextResponse.json({ success:false, error:'failed' }, { status:500 })
  }
}