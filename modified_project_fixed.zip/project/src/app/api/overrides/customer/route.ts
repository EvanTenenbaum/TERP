import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import * as Sentry from '@sentry/nextjs'
import { requireRole, getCurrentUserId } from '@/lib/auth'
import { ensurePostingUnlocked } from '@/lib/system'
import { getEffectiveUnitPrice } from '@/lib/pricing'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

export async function POST(req: Request) {
  // RBAC enforcement
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  // Posting lock enforcement
  try { await ensurePostingUnlocked(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'posting_locked' }, { status:423 }) }
  // Rate limiting
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:override-customer`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  try {
    const body = await req.json().catch(() => ({})) as any
    const { productId, categoryRefId, targetId, unitPrice, reason } = body || {}
    // Validate inputs
    if ((!productId && !categoryRefId) || !targetId || typeof unitPrice !== 'number' || unitPrice <= 0) {
      return NextResponse.json({ success:false, error:'invalid_input' }, { status:400 })
    }
    if (!reason || typeof reason !== 'string' || reason.length > 256) {
      return NextResponse.json({ success:false, error:'invalid_reason' }, { status:400 })
    }
    const now = new Date()
    // Locate or create the customer price book
    let book = await prisma.priceBook.findFirst({ where: { type:'CUSTOMER', customerId: targetId } })
    if (!book) {
      book = await prisma.priceBook.create({ data: { name: `CUSTOMER_${targetId}`, type:'CUSTOMER', customerId: targetId, effectiveDate: now, isActive: true } })
    } else if (!book.isActive) {
      await prisma.priceBook.update({ where: { id: book.id }, data: { isActive: true } })
    }
    // Compute old price if overriding a specific product
    let oldPrice = 0
    if (productId) {
      oldPrice = await getEffectiveUnitPrice(prisma as any, productId, { customerId: targetId })
    }
    const data: any = { priceBookId: book.id, unitPrice, effectiveDate: now }
    if (productId) data.productId = productId
    if (categoryRefId) data.categoryRefId = categoryRefId
    const entry = await prisma.priceBookEntry.create({ data })
    // Audit
    await prisma.overrideAudit.create({ data: { userId: getCurrentUserId(), oldPrice, newPrice: unitPrice, reason, overrideType: 'CUSTOMER' } })
    return NextResponse.json({ success:true, entry })
  } catch (error) {
    console.error('customer override error', error)
    Sentry.captureException(error)
    return NextResponse.json({ success:false, error:'failed' }, { status:500 })
  }
}