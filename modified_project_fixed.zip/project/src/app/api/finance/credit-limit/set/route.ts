import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import * as Sentry from '@sentry/nextjs'
import { requireRole, getCurrentUserId } from '@/lib/auth'
import { ensurePostingUnlocked } from '@/lib/system'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// Set or update a customer's credit limit and optional risk flag
export async function POST(req: Request) {
  // RBAC: only SUPER_ADMIN or ACCOUNTING can modify credit limits
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  // Posting lock enforcement
  try { await ensurePostingUnlocked(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'posting_locked' }, { status:423 }) }
  // Rate limiting
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:finance-credit-limit-set`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  try {
    const body = await req.json().catch(() => ({})) as any
    const { customerId, creditLimitCents, riskFlag } = body || {}
    if (!customerId || typeof creditLimitCents !== 'number' || creditLimitCents < 0) {
      return NextResponse.json({ success:false, error:'invalid_input' }, { status:400 })
    }
    if (riskFlag && !['','WATCHLIST','ON_HOLD'].includes(String(riskFlag))) {
      return NextResponse.json({ success:false, error:'invalid_risk_flag' }, { status:400 })
    }
    const updated = await prisma.customer.update({ where: { id: customerId }, data: { creditLimit: creditLimitCents, riskFlag: riskFlag || null } })
    // If risk flag is set, log a CRM note
    if (riskFlag) {
      try {
        await prisma.crmNote.create({ data: { customerId, noteDate: new Date(), noteType: 'RISK_FLAG', content: `Risk flag set to ${riskFlag}`, createdBy: getCurrentUserId() } })
      } catch (err) {
        // non-blocking
        Sentry.captureException(err)
      }
    }
    return NextResponse.json({ success:true, customer: updated })
  } catch (error) {
    console.error('credit-limit-set error', error)
    Sentry.captureException(error)
    return NextResponse.json({ success:false, error:'failed' }, { status:500 })
  }
}