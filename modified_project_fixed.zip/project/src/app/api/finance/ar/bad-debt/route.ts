import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole, getCurrentUserId } from '@/lib/auth'
import { ensurePostingUnlocked } from '@/lib/system'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'
import * as Sentry from '@sentry/nextjs'

// Create a bad debt adjustment for an accounts receivable entry.
// Body: { arId: string, amountCents: number, reason: string }
// The amountCents is clamped to the remaining balance of the AR. A CreditMemo entry is created and the AR balance is reduced accordingly.
// RBAC: ACCOUNTING, SUPER_ADMIN
// Rate limit: 60 per minute
// Posting lock enforced
export async function POST(req: NextRequest) {
  try {
    requireRole(['SUPER_ADMIN', 'ACCOUNTING'])
  } catch {
    return NextResponse.json({ success: false, error: 'forbidden' }, { status: 403 })
  }
  try {
    await ensurePostingUnlocked(['SUPER_ADMIN', 'ACCOUNTING'])
  } catch {
    return NextResponse.json({ success: false, error: 'posting_locked' }, { status: 423 })
  }
  const rl = rateLimit(`${rateKeyFromRequest(req)}:ar-bad-debt`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ success: false, error: 'rate_limited' }, { status: 429 })
  const body = await req.json().catch(() => null)
  if (!body) return NextResponse.json({ success: false, error: 'bad_json' }, { status: 400 })
  const arId = body.arId ? String(body.arId) : ''
  let amountCents = body.amountCents != null ? Number(body.amountCents) : NaN
  const reasonRaw = body.reason ? String(body.reason) : ''
  if (!arId || !Number.isFinite(amountCents) || amountCents <= 0 || !reasonRaw) {
    return NextResponse.json({ success: false, error: 'invalid_input' }, { status: 400 })
  }
  amountCents = Math.round(amountCents)
  const reason = reasonRaw.slice(0, 256)
  try {
    const result = await prisma.$transaction(async (tx) => {
      const ar = await tx.accountsReceivable.findUnique({ where: { id: arId } })
      if (!ar) return { error: 'ar_not_found' }
      const remaining = ar.balanceRemaining
      if (remaining <= 0) return { error: 'no_balance' }
      const applyAmount = amountCents > remaining ? remaining : amountCents
      // Create credit memo for bad debt
      const memo = await tx.creditMemo.create({ data: { arId, amount: applyAmount, reason } })
      // Reduce the AR balance
      await tx.accountsReceivable.update({ where: { id: arId }, data: { balanceRemaining: { decrement: applyAmount } } })
      return { memo, applied: applyAmount }
    })
    if ('error' in result) {
      const code = result.error
      const status = code === 'ar_not_found' ? 404 : code === 'no_balance' ? 400 : 400
      return NextResponse.json({ success: false, error: code }, { status })
    }
    // Emit a Sentry message for audit purposes
    try {
      Sentry.captureMessage(`Bad debt recorded on AR ${arId} for ${result.applied} cents by user ${getCurrentUserId()}`)
    } catch {}
    return NextResponse.json({ success: true, creditMemo: result.memo })
  } catch (e: any) {
    Sentry.captureException(e)
    return NextResponse.json({ success: false, error: 'server_error' }, { status: 500 })
  }
}