import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// Helper to bucket days past due for aging report
function bucket(days: number) {
  if (days >= 90) return '90+'
  if (days >= 60) return '60-89'
  if (days >= 30) return '30-59'
  if (days >= 0) return '0-29'
  return 'not_due'
}

// Export accounts receivable aging as CSV
// RBAC: SUPER_ADMIN, ACCOUNTING
// Rate limit: 30 per minute
export async function GET(req: NextRequest) {
  try {
    requireRole(['SUPER_ADMIN', 'ACCOUNTING'])
  } catch {
    return new NextResponse('forbidden', { status: 403 })
  }
  const rl = rateLimit(`${rateKeyFromRequest(req)}:export-ar-aging`, 30, 60_000)
  if (!rl.allowed) return new NextResponse('rate_limited', { status: 429 })
  const today = new Date()
  const ars = await prisma.accountsReceivable.findMany({ include: { customer: true } })
  const header = ['invoiceNumber', 'customer', 'dueDate', 'balanceCents', 'daysPastDue', 'bucket']
  const rows: string[][] = [header]
  for (const ar of ars) {
    const dueDate = new Date(ar.dueDate)
    const daysPastDue = Math.floor((today.getTime() - dueDate.getTime()) / 86400000)
    if (daysPastDue < 0 || ar.balanceRemaining <= 0) continue
    rows.push([
      ar.invoiceNumber,
      ar.customer?.companyName || ar.customerId,
      dueDate.toISOString(),
      String(ar.balanceRemaining),
      String(daysPastDue),
      bucket(daysPastDue),
    ])
  }
  const csv = rows
    .map((r) => r.map((f) => (/[",\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f)).join(','))
    .join('\n')
  return new NextResponse(csv, {
    status: 200,
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="ar_aging_${Date.now()}.csv"`,
    },
  })
}