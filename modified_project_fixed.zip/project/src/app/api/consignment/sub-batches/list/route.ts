import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// List consignment sub-batches
// Query parameters: batchId (optional), vendorId (optional)
// RBAC: SUPER_ADMIN, ACCOUNTING, READ_ONLY
// Rate: 60 requests per minute
export async function GET(req: NextRequest) {
  try {
    requireRole(['SUPER_ADMIN', 'ACCOUNTING', 'READ_ONLY'])
  } catch {
    return new NextResponse('forbidden', { status: 403 })
  }
  const rl = rateLimit(`${rateKeyFromRequest(req)}:consignment-sub-batch-list`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ error: 'rate_limited' }, { status: 429 })
  const { searchParams } = new URL(req.url)
  const batchId = searchParams.get('batchId') || undefined
  const vendorId = searchParams.get('vendorId') || undefined
  // Build where clause with optional vendorId nested filter
  const where: any = {}
  if (batchId) where.batchId = batchId
  if (vendorId) {
    where.batch = { vendorId }
  }
  const subBatches = await prisma.subBatch.findMany({
    where,
    include: {
      batch: {
        include: {
          vendor: true,
          product: true,
        },
      },
    },
  })
  return NextResponse.json({ success: true, subBatches })
}