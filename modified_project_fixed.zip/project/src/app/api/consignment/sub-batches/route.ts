import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { ensurePostingUnlocked } from '@/lib/system'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// Create a new sub-batch for consignment pricing tiers
// Body: { batchId: string, tierName: string, qtyAllocated: number, unitCostOverrideCents?: number }
// RBAC: SUPER_ADMIN, ACCOUNTING
// Rate: 60 requests per minute
// Posting lock enforced
export async function POST(req: NextRequest) {
  try {
    requireRole(['SUPER_ADMIN', 'ACCOUNTING'])
  } catch {
    return new NextResponse('forbidden', { status: 403 })
  }
  try {
    await ensurePostingUnlocked(['SUPER_ADMIN', 'ACCOUNTING'])
  } catch {
    return new NextResponse('posting_locked', { status: 423 })
  }
  const rl = rateLimit(`${rateKeyFromRequest(req)}:consignment-sub-batch-create`, 60, 60_000)
  if (!rl.allowed) return NextResponse.json({ error: 'rate_limited' }, { status: 429 })
  const body = await req.json().catch(() => null)
  if (!body) return NextResponse.json({ error: 'bad_json' }, { status: 400 })
  const batchId = body.batchId ? String(body.batchId) : ''
  const tierNameRaw = body.tierName ? String(body.tierName) : ''
  const qtyAllocatedNum = Number(body.qtyAllocated)
  const unitCostOverrideCentsNum = body.unitCostOverrideCents != null ? Number(body.unitCostOverrideCents) : undefined
  if (!batchId || !tierNameRaw || !Number.isFinite(qtyAllocatedNum) || qtyAllocatedNum <= 0) {
    return NextResponse.json({ error: 'invalid_input' }, { status: 400 })
  }
  let costOverride: number | null = null
  if (unitCostOverrideCentsNum != null) {
    if (!Number.isFinite(unitCostOverrideCentsNum) || unitCostOverrideCentsNum < 0) {
      return NextResponse.json({ error: 'invalid_cost' }, { status: 400 })
    }
    costOverride = Math.round(unitCostOverrideCentsNum)
  }
  const tierName = tierNameRaw.trim().slice(0, 64)
  return await prisma.$transaction(async (tx) => {
    // Optional: verify that the batch exists and is marked as consignment
    const batch = await tx.batch.findUnique({ where: { id: batchId } })
    if (!batch) return NextResponse.json({ error: 'batch_not_found' }, { status: 404 })
    if (!(batch as any).isConsignment) {
      // If batch is not consignment, still allow creation but warn? We choose to enforce that sub-batches only apply to consignment
      return NextResponse.json({ error: 'not_consignment_batch' }, { status: 400 })
    }
    const subBatch = await tx.subBatch.create({
      data: {
        batchId,
        tierName,
        qtyAllocated: Math.round(qtyAllocatedNum),
        unitCostOverrideCents: costOverride,
      },
    })
    return NextResponse.json({ success: true, subBatch })
  })
}