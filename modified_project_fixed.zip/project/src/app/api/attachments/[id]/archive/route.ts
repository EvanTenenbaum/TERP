import prisma from '@/lib/prisma'
import { NextRequest, NextResponse } from 'next/server'
import * as Sentry from '@sentry/nextjs'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// Archive or unarchive an attachment. Only SUPER_ADMIN and ACCOUNTING roles are allowed.
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:attachments-archive`, 30, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  try {
    const body = await req.json().catch(() => ({})) as any
    const archived = !!body.archived
    const att = await prisma.attachment.update({ where: { id: params.id }, data: { archived } })
    // Log archive action via Sentry for visibility
    Sentry.captureMessage(`Attachment ${att.id} archived: ${archived}`)
    return NextResponse.json({ success:true, attachment: att })
  } catch (error) {
    Sentry.captureException(error)
    return NextResponse.json({ success:false, error:'failed' }, { status:500 })
  }
}