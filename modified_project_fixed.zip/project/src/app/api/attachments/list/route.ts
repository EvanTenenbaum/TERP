import prisma from '@/lib/prisma'
import { NextRequest, NextResponse } from 'next/server'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

export async function GET(req: NextRequest) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING','SALES','READ_ONLY']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  // Rate limit: 30/min
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:attachments-list`, 30, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  const { searchParams } = new URL(req.url)
  const entityType = searchParams.get('entityType') || undefined
  const entityId = searchParams.get('entityId') || undefined
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10) || 1)
  const pageSizeRaw = parseInt(searchParams.get('pageSize') || '50', 10) || 50
  const pageSize = Math.min(200, Math.max(1, pageSizeRaw))
  const where: any = {}
  if (entityType) where.entityType = entityType
  if (entityId) where.entityId = entityId
  const [attachments, total] = await Promise.all([
    prisma.attachment.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
      select: { id:true, entityType:true, entityId:true, fileName:true, mimeType:true, fileSize:true, archived:true, createdAt:true }
    }),
    prisma.attachment.count({ where })
  ])
  return NextResponse.json({ success: true, data: attachments, meta: { total, page, pageSize } })
}
