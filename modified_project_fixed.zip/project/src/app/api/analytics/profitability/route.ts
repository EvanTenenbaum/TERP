import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

// Export profitability data with optional filters and formats.
export async function GET(req: NextRequest) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING','READ_ONLY']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:analytics-profitability-export`, 30, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  const { searchParams } = new URL(req.url)
  const sinceStr = searchParams.get('since') || ''
  const untilStr = searchParams.get('until') || ''
  const format = (searchParams.get('format') || 'json').toLowerCase()
  const vendorId = searchParams.get('vendorId') || undefined
  const productId = searchParams.get('productId') || undefined
  const since = sinceStr ? new Date(sinceStr) : new Date(Date.now() - 30*24*3600*1000)
  const until = untilStr ? new Date(untilStr) : new Date()
  const entries = await prisma.profitabilityLedger.findMany({
    where: { runDate: { gte: since, lte: until }, vendorId: vendorId || undefined, batch: productId ? { productId } : undefined },
    orderBy: { runDate: 'asc' }
  })
  if (format === 'csv') {
    const header = 'runDate,vendorId,productId,revenue,cogs,opex,badDebt,margin\n'
    const rows = entries.map((e) => [e.runDate.toISOString(), e.vendorId || '', e.batchId || '', e.revenue, e.cogs, e.opex, e.badDebt, e.margin].join(','))
    const csv = header + rows.join('\n')
    return new NextResponse(csv, { headers: { 'Content-Type': 'text/csv' } })
  }
  return NextResponse.json({ success:true, data: entries })
}