import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { rateKeyFromRequest, rateLimit } from '@/lib/rateLimit'

export async function GET(req: NextRequest) {
  try { requireRole(['SUPER_ADMIN','ACCOUNTING','READ_ONLY']) } catch { return NextResponse.json({ success:false, error:'forbidden' }, { status:403 }) }
  const rl = rateLimit(`${rateKeyFromRequest(req as any)}:audit-get`, 30, 60_000)
  if (!rl.allowed) return NextResponse.json({ success:false, error:'rate_limited' }, { status:429 })
  const { searchParams } = new URL(req.url)
  const entityType = searchParams.get('entityType') || undefined
  const entityId = searchParams.get('entityId') || undefined
  const userId = searchParams.get('userId') || undefined
  const fromStr = searchParams.get('from') || undefined
  const toStr = searchParams.get('to') || undefined
  const format = (searchParams.get('format') || 'json').toLowerCase()
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10) || 1)
  const pageSizeRaw = parseInt(searchParams.get('pageSize') || '100', 10) || 100
  const pageSize = Math.min(500, Math.max(1, pageSizeRaw))
  const from = fromStr ? new Date(fromStr) : undefined
  const to = toStr ? new Date(toStr) : undefined

  // Build query conditions for each log source
  const transferWhere: any = {}
  if (entityType === 'product' && entityId) transferWhere.productId = entityId
  if (from || to) transferWhere.createdAt = {}
  if (from) transferWhere.createdAt.gte = from
  if (to) transferWhere.createdAt.lte = to
  const writeoffWhere: any = {}
  if (entityType === 'lot' && entityId) writeoffWhere.lotId = entityId
  if (from || to) writeoffWhere.createdAt = {}
  if (from) writeoffWhere.createdAt.gte = from
  if (to) writeoffWhere.createdAt.lte = to
  const settlementWhere: any = {}
  const rebateWhere: any = {}
  if (entityType === 'vendor' && entityId) {
    settlementWhere.vendorId = entityId
    rebateWhere.vendorId = entityId
  }
  if (from || to) {
    settlementWhere.createdAt = {}
    rebateWhere.createdAt = {}
    if (from) { settlementWhere.createdAt.gte = from; rebateWhere.createdAt.gte = from }
    if (to) { settlementWhere.createdAt.lte = to; rebateWhere.createdAt.lte = to }
  }
  const overrideWhere: any = {}
  if (entityType === 'order' && entityId) overrideWhere.orderId = entityId
  if (entityType === 'quote' && entityId) overrideWhere.quoteId = entityId
  if (userId) overrideWhere.userId = userId
  if (from || to) {
    overrideWhere.timestamp = {}
    if (from) overrideWhere.timestamp.gte = from
    if (to) overrideWhere.timestamp.lte = to
  }
  const [transfers, writeoffs, settlements, rebates, overrides, counts] = await Promise.all([
    prisma.inventoryTransfer.findMany({ where: Object.keys(transferWhere).length ? transferWhere : undefined, orderBy:{ createdAt:'desc' }, skip:(page-1)*pageSize, take:pageSize }),
    prisma.writeOffLedger.findMany({ where: Object.keys(writeoffWhere).length ? writeoffWhere : undefined, orderBy:{ createdAt:'desc' }, skip:(page-1)*pageSize, take:pageSize }),
    prisma.vendorSettlement.findMany({ where: Object.keys(settlementWhere).length ? settlementWhere : undefined, orderBy:{ createdAt:'desc' }, skip:(page-1)*pageSize, take:pageSize }),
    prisma.vendorRebate.findMany({ where: Object.keys(rebateWhere).length ? rebateWhere : undefined, orderBy:{ createdAt:'desc' }, skip:(page-1)*pageSize, take:pageSize }),
    prisma.overrideAudit.findMany({ where: Object.keys(overrideWhere).length ? overrideWhere : undefined, orderBy:{ timestamp:'desc' }, skip:(page-1)*pageSize, take:pageSize }),
    prisma.overrideAudit.count({ where: Object.keys(overrideWhere).length ? overrideWhere : undefined })
  ])
  const items: any[] = []
  for (const t of transfers) items.push({ when: t.createdAt, type: 'inventory.transfer', summary: `Transfer ${t.quantity} ${t.sourceLotId} → ${t.destLotId || '-'} for ${t.productId}` })
  for (const w of writeoffs) items.push({ when: w.createdAt, type: 'inventory.writeoff', summary: `Write-off ${w.qty} from lot ${w.lotId} (${w.reason})` })
  for (const s of settlements) items.push({ when: s.createdAt, type: 'ap.settlement', summary: `Vendor settlement ${s.amount} for ${s.vendorId}` })
  for (const r of rebates) items.push({ when: r.createdAt, type: 'ap.rebate', summary: `Vendor rebate ${r.amount} for ${r.vendorId}` })
  for (const o of overrides) items.push({ when: o.timestamp, type: 'override', summary: `Override ${o.oldPrice}→${o.newPrice} (${o.reason})`, userId: o.userId })
  // Sort by date desc
  items.sort((a,b) => new Date(b.when).getTime() - new Date(a.when).getTime())
  if (format === 'csv') {
    const header = 'when,type,summary\n'
    const csvRows = items.map((i) => `${new Date(i.when).toISOString()},${i.type},"${i.summary.replace(/"/g, '""')}"`)
    const csv = header + csvRows.join('\n')
    return new NextResponse(csv, { headers: { 'Content-Type': 'text/csv' } })
  }
  return NextResponse.json({ success:true, data: items.slice(0, pageSize), meta: { page, pageSize } })
}
