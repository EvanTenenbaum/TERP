"use client"
import React, { useRef, useState } from 'react'
import useSWR from 'swr'

export interface AttachmentPanelProps {
  entityType: string
  entityId: string
}

// A simple attachment panel to list, upload and archive attachments for a given entity.
// This component uses SWR for data fetching and provides basic UI elements.
const AttachmentPanel: React.FC<AttachmentPanelProps> = ({ entityType, entityId }) => {
  const fetcher = (url: string) => fetch(url).then((res) => res.json())
  const { data, error, mutate } = useSWR(() => `/api/attachments/list?entityType=${encodeURIComponent(entityType)}&entityId=${encodeURIComponent(entityId)}`, fetcher)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)

  const handleUpload = async () => {
    const file = fileInputRef.current?.files?.[0]
    if (!file) return
    const formData = new FormData()
    formData.append('file', file)
    formData.append('entityType', entityType)
    formData.append('entityId', entityId)
    setUploading(true)
    try {
      const res = await fetch('/api/attachments/upload', { method: 'POST', body: formData })
      if (res.ok) await mutate()
    } finally {
      setUploading(false)
      if (fileInputRef.current) fileInputRef.current.value = ''
    }
  }

  const handleArchive = async (id: string) => {
    await fetch(`/api/attachments/${id}/archive`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ archived: true }) })
    await mutate()
  }

  if (error) return <div>Error loading attachments</div>

  const attachments = data?.data || data?.attachments || []

  return (
    <div className="space-y-2">
      <div className="flex items-center space-x-2">
        <input type="file" ref={fileInputRef} className="border p-1" />
        <button onClick={handleUpload} disabled={uploading} className="px-2 py-1 bg-blue-500 text-white rounded">
          {uploading ? 'Uploading...' : 'Upload'}
        </button>
      </div>
      <ul className="divide-y">
        {attachments.map((att: any) => (
          <li key={att.id} className="flex justify-between items-center py-1">
            <a href={`/api/attachments/file?id=${att.id}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">
              {att.fileName}
            </a>
            {!att.archived && (
              <button onClick={() => handleArchive(att.id)} className="text-sm text-red-500 underline">
                Archive
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  )
}

export default AttachmentPanel