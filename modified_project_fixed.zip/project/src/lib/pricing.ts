import type { PrismaClient } from '@prisma/client'

// Get effective unit price given product and optional customer
/**
 * Compute the list of category IDs from a given category up through its ancestors.
 * Returns an array with the starting category first followed by its parents.
 */
async function getCategoryAncestry(db: any, categoryId: string | null | undefined): Promise<string[]> {
  const ids: string[] = []
  let currentId: string | undefined | null = categoryId
  while (currentId) {
    ids.push(currentId)
    const parent = await db.productCategory.findUnique({ where: { id: currentId }, select: { parentId: true } })
    currentId = parent?.parentId ?? undefined
  }
  return ids
}

// Get effective unit price given product and optional customer/role
export async function getEffectiveUnitPrice(
  db: Pick<PrismaClient, any> | any,
  productId: string,
  opts?: { customerId?: string; roleId?: string }
): Promise<number> {
  const now = new Date()

  // Fetch product default and category for ancestor lookup
  const prod = await db.product.findUnique({ where: { id: productId }, select: { defaultPrice: true, categoryRefId: true } })
  if (!prod) throw new Error('product_not_found')
  const categoryIds = await getCategoryAncestry(db, prod.categoryRefId)

  // Helper to resolve price within a given scope (CUSTOMER, ROLE, GLOBAL)
  async function resolvePrice(scope: 'CUSTOMER' | 'ROLE' | 'GLOBAL', targetId?: string): Promise<number | null> {
    // 1) Product-specific pricing
    const productMatch = await db.priceBookEntry.findFirst({
      where: {
        productId,
        priceBook: {
          type: scope,
          customerId: scope === 'CUSTOMER' ? targetId : undefined,
          roleId: scope === 'ROLE' ? targetId : undefined,
          isActive: true,
          effectiveDate: { lte: now },
        },
        effectiveDate: { lte: now },
        categoryRefId: null,
      },
      orderBy: { effectiveDate: 'desc' },
    })
    if (productMatch) return productMatch.unitPrice
    // 2) Category-based pricing (check closest ancestor first)
    for (const catId of categoryIds) {
      const catMatch = await db.priceBookEntry.findFirst({
        where: {
          categoryRefId: catId,
          priceBook: {
            type: scope,
            customerId: scope === 'CUSTOMER' ? targetId : undefined,
            roleId: scope === 'ROLE' ? targetId : undefined,
            isActive: true,
            effectiveDate: { lte: now },
          },
          effectiveDate: { lte: now },
        },
        orderBy: { effectiveDate: 'desc' },
      })
      if (catMatch) return catMatch.unitPrice
    }
    return null
  }

  // Check customer-specific price
  if (opts?.customerId) {
    const price = await resolvePrice('CUSTOMER', opts.customerId)
    if (price != null) return price
  }
  // Check role-specific price
  if (opts?.roleId) {
    const price = await resolvePrice('ROLE', opts.roleId)
    if (price != null) return price
  }
  // Global pricing
  {
    const price = await resolvePrice('GLOBAL')
    if (price != null) return price
  }
  // Fallback to product default
  return prod.defaultPrice
}
